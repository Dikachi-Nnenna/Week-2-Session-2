import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Color _backgroundColor = Colors.pink;

  void _changeColor() {
    setState(() {
      _backgroundColor = _backgroundColor == Color.fromRGBO(153, 124, 134, 1) ? Colors.blue : Colors.pink;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: _backgroundColor,
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: NetworkImage('https://i.picsum.photos/id/1005/5760/3840.jpg'),
              fit: BoxFit.cover,
            ),
          ),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: Text('Primary Dysmenorrhea'),
                subtitle: Text('This is the most common type of period pain. It is caused by the contraction of the uterus and is usually felt in the lower abdomen or back.'),
              ),
              ListTile(
                title: Text('Secondary Dysmenorrhea'),
                subtitle: Text('This type of period pain is caused by an underlying medical condition, such as endometriosis or fibroids.'),
              ),
              ListTile(
                title: Text('Dysfunctional Uterine Bleeding'),
                subtitle: Text('This type of period pain is characterized by abnormal bleeding patterns and can be caused by hormonal imbalances or other medical conditions.'),
              ),
              Center(
                child: FlatButton(
                  color: Colors.black,
                  child: Text('Click here'),
                  TextColor: Colors.white,
                  onPressed:(){},
                  child: Text("Change Color"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
